﻿using System;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Reflection.Metadata.Ecma335;

namespace Roulette123
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Welcome to my roulette game, I am very excited to take your money!");
            StartHere.BetSelect();

        }
        
    }
   
    
   
   
    
}

